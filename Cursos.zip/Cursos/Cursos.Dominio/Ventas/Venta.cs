using Cursos.Dominio.Abstractions;

namespace Cursos.Dominio.Ventas;

public class Venta : Entity
{
    public Venta(
        int idVenta,
        int idAlumno,
        DateTime fecha,
        decimal total) : base(idVenta)
    {
        IdAlumno = idAlumno;
        Fecha = fecha;
        Total = total;
    }

    public int IdAlumno { get; private set; }
    public DateTime Fecha { get; private set; }
    public decimal Total { get; private set; }
}
