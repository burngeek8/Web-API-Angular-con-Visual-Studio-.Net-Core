namespace Cursos.Aplicacion.Cursos.ListarCursos;

public record CursoResponse
(
    int IdCurso,
    string Codigo,
    string Nombre,
    int CantidadHoras,
    decimal Precio,
    string Silabo
);
