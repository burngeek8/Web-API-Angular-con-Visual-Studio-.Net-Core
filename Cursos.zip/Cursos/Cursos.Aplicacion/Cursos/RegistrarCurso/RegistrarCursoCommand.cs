using Cursos.Aplicacion.Abstractions.Messaging;

namespace Cursos.Aplicacion.Cursos.RegistrarCurso;

public sealed record RegistrarCursoCommand
(
    string Nombre,
    int CantidadHoras,
    decimal Precio,
    string Silabo
) : ICommand<int>;
