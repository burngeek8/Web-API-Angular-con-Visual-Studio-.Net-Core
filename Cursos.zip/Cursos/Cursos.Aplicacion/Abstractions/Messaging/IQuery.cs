using MediatR;

namespace Cursos.Aplicacion.Abstractions.Messaging;

public interface IQuery<TResult> : IRequest<TResult>
{
}
