using Cursos.Dominio.Abstractions;

namespace Cursos.Dominio.DetalleVentas;

public class DetalleVenta : Entity
{
    public DetalleVenta(
        int idDetalleVenta,
        int idCurso,
        int cantidad,
        decimal precio,
        decimal total) : base(idDetalleVenta)
    {
        IdCurso = idCurso;
        Cantidad = cantidad;
        Precio = precio;
        Total = total;
    }

    public int IdCurso { get; private set; }
    public int Cantidad { get; private set; }
    public decimal Precio { get; private set; }
    public decimal Total { get; private set; }
}
