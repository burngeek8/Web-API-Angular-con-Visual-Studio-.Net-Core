using Cursos.Aplicacion.Abstractions.Messaging;
using Cursos.Dominio.Cursos.Repository;

namespace Cursos.Aplicacion.Cursos.ListarCursos;

internal sealed class ListarCursosQueryHandler : IQueryHandler<ListarCursosQuery, List<CursoResponse>>
{
    private readonly ICursoRepository _cursoRepository;

    public ListarCursosQueryHandler(ICursoRepository cursoRepository)
    {
        _cursoRepository = cursoRepository;
    }

    public async Task<List<CursoResponse>> Handle(ListarCursosQuery request, CancellationToken cancellationToken)
    {
        var cursos = await _cursoRepository.ListAsync(cancellationToken);

        return cursos
            .Select(curso => new CursoResponse(
                curso.Id,
                curso.Codigo,
                curso.Nombre,
                curso.CantidadHoras,
                curso.Precio,
                curso.Silabo))
            .ToList();
    }
}
