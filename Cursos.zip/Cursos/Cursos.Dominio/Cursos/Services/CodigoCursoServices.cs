using Cursos.Dominio.Cursos.ObjectValue;

namespace Cursos.Dominio.Cursos.Services;

public class CodigoCursoServices
{
    public CodigoCurso GenerarCodigo(string nombre, int cantidadHoras)
    {
        var iniciales = string.Concat(
            nombre
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Where(palabra => palabra.Length > 2)
                .Take(3)
                .Select(palabra => char.ToUpperInvariant(palabra[0])));

        if (string.IsNullOrWhiteSpace(iniciales))
            iniciales = "CUR";

        return CodigoCurso.Create($"{DateTime.UtcNow:yyyyMM}-{iniciales}-{cantidadHoras}H");
    }
}
