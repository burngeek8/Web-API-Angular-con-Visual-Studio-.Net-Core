namespace Cursos.Dominio.Cursos.ObjectValue;

public record Silabo
{
    private Silabo(string valor)
    {
        Valor = valor;
    }

    public string Valor { get; init; }

    public static Silabo Create(string valor)
    {
        if (string.IsNullOrWhiteSpace(valor))
            throw new ArgumentException("El silabo del curso no puede estar vacio.");

        return new Silabo(valor);
    }
}
