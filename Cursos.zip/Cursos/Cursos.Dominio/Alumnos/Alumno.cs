using Cursos.Dominio.Abstractions;

namespace Cursos.Dominio.Alumnos;

public class Alumno : Entity
{
    public Alumno(
        int idAlumno,
        string nombres,
        string apellidos,
        string direccion,
        string ciudad) : base(idAlumno)
    {
        Nombres = nombres;
        Apellidos = apellidos;
        Direccion = direccion;
        Ciudad = ciudad;
    }

    public string Nombres { get; private set; }
    public string Apellidos { get; private set; }
    public string Direccion { get; private set; }
    public string Ciudad { get; private set; }
}
