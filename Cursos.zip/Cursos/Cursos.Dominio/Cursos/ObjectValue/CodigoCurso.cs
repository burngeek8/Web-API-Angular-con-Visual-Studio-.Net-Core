namespace Cursos.Dominio.Cursos.ObjectValue;

public record CodigoCurso
{
    private CodigoCurso(string valor)
    {
        Valor = valor;
    }

    public string Valor { get; init; }

    public static CodigoCurso Create(string valor)
    {
        if (string.IsNullOrWhiteSpace(valor))
            throw new ArgumentException("El codigo del curso no puede estar vacio.");

        return new CodigoCurso(valor);
    }
}
