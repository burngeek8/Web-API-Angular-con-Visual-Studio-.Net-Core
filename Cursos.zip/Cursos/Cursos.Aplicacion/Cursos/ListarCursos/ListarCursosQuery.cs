using Cursos.Aplicacion.Abstractions.Messaging;

namespace Cursos.Aplicacion.Cursos.ListarCursos;

public sealed record ListarCursosQuery : IQuery<List<CursoResponse>>;
