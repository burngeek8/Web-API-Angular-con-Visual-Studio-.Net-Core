namespace Cursos.Dominio.Cursos.ObjectValue;

public record NombreCurso
{
    private NombreCurso(string valor)
    {
        Valor = valor;
    }

    public string Valor { get; init; }

    public static NombreCurso Create(string valor)
    {
        if (string.IsNullOrWhiteSpace(valor))
            throw new ArgumentException("El nombre del curso no puede estar vacio.");

        return new NombreCurso(valor);
    }
}
