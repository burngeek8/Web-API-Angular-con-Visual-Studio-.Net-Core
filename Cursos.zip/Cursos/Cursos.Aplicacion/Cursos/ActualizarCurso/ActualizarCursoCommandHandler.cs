using Cursos.Aplicacion.Abstractions.Messaging;
using Cursos.Dominio.Abstractions;
using Cursos.Dominio.Cursos.Repository;

namespace Cursos.Aplicacion.Cursos.ActualizarCurso;

internal sealed class ActualizarCursoCommandHandler : ICommandHandler<ActualizarCursoCommand>
{
    private readonly ICursoRepository _cursoRepository;
    private readonly IUnitOfWork _unitOfWork;

    public ActualizarCursoCommandHandler(
        ICursoRepository cursoRepository,
        IUnitOfWork unitOfWork)
    {
        _cursoRepository = cursoRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task Handle(ActualizarCursoCommand request, CancellationToken cancellationToken)
    {
        var curso = await _cursoRepository.GetByIdAsync(request.IdCurso, cancellationToken);
        if (curso is null)
            throw new Exception($"No se encontro el curso con ID: {request.IdCurso}");

        curso.Actualizar(
            request.Nombre,
            request.CantidadHoras,
            request.Precio,
            request.Silabo);

        _cursoRepository.Update(curso);
        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }
}
