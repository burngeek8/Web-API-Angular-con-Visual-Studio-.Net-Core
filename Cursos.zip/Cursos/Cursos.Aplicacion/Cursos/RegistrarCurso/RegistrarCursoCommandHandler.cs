using Cursos.Aplicacion.Abstractions.Messaging;
using Cursos.Dominio.Abstractions;
using Cursos.Dominio.Cursos.Repository;
using Cursos.Dominio.Cursos.Services;

namespace Cursos.Aplicacion.Cursos.RegistrarCurso;

internal sealed class RegistrarCursoCommandHandler : ICommandHandler<RegistrarCursoCommand, int>
{
    private readonly ICursoRepository _cursoRepository;
    private readonly CodigoCursoServices _codigoCursoServices;
    private readonly IUnitOfWork _unitOfWork;

    public RegistrarCursoCommandHandler(
        ICursoRepository cursoRepository,
        CodigoCursoServices codigoCursoServices,
        IUnitOfWork unitOfWork)
    {
        _cursoRepository = cursoRepository;
        _codigoCursoServices = codigoCursoServices;
        _unitOfWork = unitOfWork;
    }

    public async Task<int> Handle(RegistrarCursoCommand request, CancellationToken cancellationToken)
    {
        var curso = Dominio.Cursos.Curso.Create(
            request.Nombre,
            request.CantidadHoras,
            request.Precio,
            request.Silabo,
            _codigoCursoServices);

        _cursoRepository.Add(curso);
        await _unitOfWork.SaveChangesAsync(cancellationToken);
        return curso.Id;
    }
}
