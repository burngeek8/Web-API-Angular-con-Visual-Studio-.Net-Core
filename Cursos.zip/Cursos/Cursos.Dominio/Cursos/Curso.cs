using Cursos.Dominio.Abstractions;
using Cursos.Dominio.Cursos.ObjectValue;
using Cursos.Dominio.Cursos.Services;

namespace Cursos.Dominio.Cursos;

public class Curso : Entity
{
    private Curso(
        int idCurso,
        NombreCurso nombre,
        int cantidadHoras,
        decimal precio,
        Silabo silabo,
        CodigoCurso codigoCurso) : base(idCurso)
    {
        NombreCurso = nombre;
        CantidadHoras = cantidadHoras;
        Precio = precio;
        SilaboCurso = silabo;
        CodigoCurso = codigoCurso;
    }

    public NombreCurso NombreCurso { get; private set; }
    public int CantidadHoras { get; private set; }
    public decimal Precio { get; private set; }
    public Silabo SilaboCurso { get; private set; }
    public CodigoCurso CodigoCurso { get; private set; }
    public string Nombre => NombreCurso.Valor;
    public string Silabo => SilaboCurso.Valor;
    public string Codigo => CodigoCurso.Valor;

    public static Curso Create(
        string nombre,
        int cantidadHoras,
        decimal precio,
        string silabo,
        CodigoCursoServices codigoCursoServices)
    {
        return new Curso(
            0,
            NombreCurso.Create(nombre),
            cantidadHoras,
            precio,
            ObjectValue.Silabo.Create(silabo),
            codigoCursoServices.GenerarCodigo(nombre, cantidadHoras));
    }

    public void Actualizar(
        string nombre,
        int cantidadHoras,
        decimal precio,
        string silabo)
    {
        NombreCurso = NombreCurso.Create(nombre);
        CantidadHoras = cantidadHoras;
        Precio = precio;
        SilaboCurso = ObjectValue.Silabo.Create(silabo);
    }
}
