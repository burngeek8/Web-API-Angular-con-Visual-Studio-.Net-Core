using Cursos.Aplicacion.Abstractions.Messaging;

namespace Cursos.Aplicacion.Cursos.ActualizarCurso;

public sealed record ActualizarCursoCommand
(
    int IdCurso,
    string Nombre,
    int CantidadHoras,
    decimal Precio,
    string Silabo
) : ICommand;
