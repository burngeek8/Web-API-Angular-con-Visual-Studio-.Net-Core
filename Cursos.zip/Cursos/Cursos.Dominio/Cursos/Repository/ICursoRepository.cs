namespace Cursos.Dominio.Cursos.Repository;

public interface ICursoRepository
{
    void Add(Curso curso);

    void Update(Curso curso);

    Task<Curso?> GetByIdAsync(int idCurso, CancellationToken cancellationToken = default);

    Task<List<Curso>> ListAsync(CancellationToken cancellationToken = default);
}
