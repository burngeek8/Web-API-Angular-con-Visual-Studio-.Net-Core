using Cursos.Dominio.Cursos.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Cursos.Aplicacion;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(DependencyInjection).Assembly));
        services.AddTransient<CodigoCursoServices>();

        return services;
    }
}
